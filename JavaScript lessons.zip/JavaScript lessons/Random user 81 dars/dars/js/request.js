// api
const API = 'https://randomuser.me/api/?results=9'

// for leader
const overlay = document.getElementById('overlay')
const loaderToggle = (toggle)=>{
	if(toggle){
		overlay.classList.remove('hidden')
	}else{
		overlay.classList.add('hidden')
	}
}
// getData
const getData = (link) => {
	return new Promise((resolve, reject) => {
		let request = new XMLHttpRequest();
		request.addEventListener('readystatechange', ()=>{
			if(request.status === 200 && request.readyState === 4){
				data = JSON.parse(request.responseText).results
				resolve(data)
				loaderToggle(false)
			}else if(request.readyState < 4){
				loaderToggle(true);
			}else if(request.readyState == 4){
				reject('Error !!!!')
				loaderToggle(false)
			}
		})


		request.open("GET", link)
		request.send();
	})
}

const reload = ()=>{
	getData(API).then((data)=>{
		updateUI(data)
	}).catch((err)=>{
		console.log(err)
	})
}

document.addEventListener('DOMContentLoaded', reload)