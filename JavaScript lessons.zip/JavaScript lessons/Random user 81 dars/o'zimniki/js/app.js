const form = document.getElementById('form')
const formButton = document.getElementById('form__button')
const user = document.getElementById('user')
const deleteBtn = document.getElementById('delete__btn')
const clearBtn = document.getElementById('clear__button')
const formInp = document.getElementById('form__input')

function rename(data) {
	data.forEach( (item) => {
		const {gender, name, location, dob, picture} = item
		user.innerHTML += `
		<li class="user__item">
              <button id="delete__btn" class="user__delete--btn">
                <i class="fas fa-trash"></i>
              </button>
              <img
                class="user__img"
                alt="User photo"
                src=${picture.large}
                width="100"
                height="100"
              />
              <div class="user__name">
                <span class="material-symbols-outlined">badge</span>
                <span>- ${name.title} ${name.first} ${name.last}</span>
              </div>
              <div class="user__year">
                <span class="material-symbols-outlined">cake</span>
                <span>- ${dob.age} years old.</span>
              </div>
              <div class="user__location">
                <span class="material-symbols-outlined">person_pin_circle</span>
                <span>- ${location.state}, ${location.country}</span>
              </div>
              <div class="user__gender">
                <span class="material-symbols-outlined">man</span>
                <span>- ${gender}</span>
              </div>
            </li>
		`
	})
}
// clera button
clearBtn.addEventListener('click', (e)=>{
	e.preventDefault()
	user.innerHTML = ''
	clearBtn.classList.add('hidden')
})
// refresh button
formButton.addEventListener('click', (e)=>{
	e.preventDefault();
	clearBtn.classList.remove('hidden');
	getTodo(API).then((data)=>{
		user.innerHTML = ``;
		rename(data)
	}).catch((err)=>{
		document.querySelector('body').innerHTML = `<h1 style = "text-align:center">${err}</h1>`
	})
})

if(user.innerHTML == true){
	clearBtn.classList.remove('hidden')
}

form['form__input'].addEventListener('input', (e)=>{
	const inputVal = e.target.value.toLowerCase();
	const nameSearch = document.querySelectorAll('.user__name')
	nameSearch.forEach((item)=>{
		const searced = item.lastChild.previousSibling.textContent.toLowerCase()
		if(searced.includes(inputVal)){
			item.parentElement.classList.remove('hidden');
		}else if(!searced.includes(inputVal)){
			item.parentElement.classList.add('hidden');
		}
	})
})
// remove one
document.addEventListener('click', (e)=>{
	const deleted = document.querySelectorAll('.user__delete--btn')
	deleted.forEach((items)=>{
		if(e.target == items){
			items.parentElement.remove();
		}
	})
	if(user.children.length == false){
		clearBtn.classList.add('hidden')
	}
})