// api
const API = 'https://randomuser.me/api/?results=9'

// for leader
const overlay = document.getElementById('overlay')

const getTodo = (link)=>{
	return new Promise((resolve, reject) => {
		let request = new XMLHttpRequest();
		request.addEventListener('readystatechange', ()=>{
			if(request.status === 200 && request.readyState === 4){
				data = JSON.parse(request.responseText).results
				resolve(data)
				overlay.classList.add('hidden')
			}else if(request.readyState < 4){
				overlay.classList.remove('hidden')
			}else if(request.status !== 200){
				reject("Error client !!!")
			}
		})
		request.open('GET', link)
		request.send();
	})
}
getTodo(API).then((data)=>{
	rename(data)
}).catch((err)=>{
	document.querySelector('body').innerHTML = `<h1 style = "text-align:center">${err}</h1>`
})