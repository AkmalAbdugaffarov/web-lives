const body = document.querySelector('body')
const darkBtn = document.getElementById('dark-btn')
const lightBtn = document.getElementById('light-btn')
const getLocal = localStorage.getItem('list')
const sideLogo = document.querySelector('.site-logo');
sideLogo.addEventListener('click', (e)=>{
	e.preventDefault()
})

document.addEventListener('DOMContentLoaded', ()=>{
	if(getLocal){
		darkBtn.classList.add('hidden')
		body.classList.add('dark-mode')
		lightBtn.classList.remove('hidden')
	}
})

const modeToggle = ()=>{
	lightBtn.classList.toggle('hidden')
	darkBtn.classList.toggle('hidden')
	body.classList.toggle('dark-mode')
}
darkBtn.addEventListener('click', ()=>{
	modeToggle()
	localStorage.setItem('list', 'dark-mode')
})
lightBtn.addEventListener('click', ()=>{
	modeToggle()
	localStorage.setItem('list', '')
})