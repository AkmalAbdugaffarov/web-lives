const API = './add.json';
/*
let getInfo = (resurse, collback)=>{
	let request = new XMLHttpRequest();

	request.addEventListener('readystatechange', ()=>{
		if(request.status === 200 && request.readyState === 4){
			data = JSON.parse(request.responseText)
			collback(data)
		}else if(request.readyState === 4){
			collback("Error client adress !!!")
		}
	})

	request.open('GET', resurse);
	request.send();
}
getInfo(API, (data, err)=>{
	if(data){
		console.log(data)
	}
	getInfo("vghjkflgkjfhdg", (data, err)=>{
		if(data){
			console.log(data);
		}
		getInfo("ghjkrkgnekjrnbg", (data, erer)=>{
			if(data){
				console.log(data)
			}else{
				console.log(erer)
			}
	})
})
})*/


/*
function getInfo(params) {
	return new Promise((resolve, reject) => {
		let request = new XMLHttpRequest();

		request.addEventListener('readystatechange', ()=>{
			if(request.status === 200 && request.readyState === 4){
				data = JSON.parse(request.responseText)
				resolve(data)
			}else if(request.readyState === 4){
				reject("errer client")
			}
		})

		request.open("GET", params)
		request.send()
	})
}
getInfo(API).then((data)=>{
	console.log(data)
	return getInfo("./add copy.json")
}).then((data)=>{
	console.log(data)
	return getInfo("./add copy 2.json")
}).then((data)=>{
	console.log(data)
}).catch((err)=>{
	console.log(err)
})
*/


/*
fetch(API).then((data)=>{
	return data.json()
}).then((dataJson)=>{
	console.log(dataJson)
	return fetch("./add copy 2.json")
}).then((data)=>{
	return data.json()
}).then((dataJSON)=>{
	console.log(dataJSON)
}).catch((err)=>{
	err = 'Error client !!!'
	console.log(err)
})
*/

/*
let getInfo = async(resurse)=>{
	let request = await fetch(resurse)
	let data = await request.json()
	return data
}

getInfo("./add copy2.json").then((data)=>{
	console.log(data)
	return getInfo("./addcopy.json")
}).then((data)=>{
	console.log(data)
	return getInfo("./addjson")
}).then((data)=>{
	console.log(data)
}).catch(()=>{
	console.log("Error client adres!!!")
})
*/