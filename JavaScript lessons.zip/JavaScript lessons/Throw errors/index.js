const getTodo = async(links)=>{
	const request = await fetch(links)
	const data = await request.json()
	if(request.status != 200){
		 throw new Error('Hatolik bor tekshirib koring!!!')
	}
	return data
}

getTodo("./add copy 2.json").then((data)=>{
	console.log(data)
}).catch(()=>{
	console.log('Hatolik bor')
})