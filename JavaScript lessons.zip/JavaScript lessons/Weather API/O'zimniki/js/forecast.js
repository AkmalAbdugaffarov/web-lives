const KEY = '9fde44a396c60620eb7475f0354f473f'
// bu mening kalitim. Agar o'zingiz olsangiz va ishlamasa buni ishlating.
// Agar ishlamay qolsa unda 1 soatda so'rovlar soni limitdan oshib ketgan bo'ladi.
// Aloqa: Telegram => @akror_web
// "https://api.openweathermap.org/data/2.5/weather?q=London&units=metric&appid=9fde44a396c60620eb7475f0354f473f"

async function getData(city) {
	let brek = `https://api.openweathermap.org/data/2.5/weather`
	let query = `?q=${city}&units=metric&appid=${KEY}`
	overlay.classList.remove('d-none')
	const request = await fetch(brek + query)
	const data = await request.json();
	overlay.classList.add('d-none')
	return data
}
